Ledgerly - Chrome extension (unpacked)

1. Unzip this folder.
2. Open chrome://extensions
3. Turn on Developer mode (top right).
4. Click "Load unpacked" and select this folder.

Your keys are created and stored on your device only.